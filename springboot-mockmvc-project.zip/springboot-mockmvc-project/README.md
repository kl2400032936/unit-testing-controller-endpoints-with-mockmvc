# Spring Boot MockMvc Controller Testing

Aim: To test Spring Boot controller endpoints using MockMvc and JUnit.

Requirements: Java 17+ and Maven.

Run tests:
```bash
mvn test
```

Endpoint tested: `GET /ms1/add?a=5&b=10`

Expected response: `MS1.1 - Addition = 15`

To run the application, start `DemoApplication.java` and visit:
`http://localhost:8080/ms1/add?a=5&b=10`
